import { createBrowserRouter } from "react-router";
import { Home } from "./pages/Home";
import { DiarioOficial } from "./pages/DiarioOficial";
import { CamaraLegislativa } from "./pages/CamaraLegislativa";
import { ContasPublicas } from "./pages/ContasPublicas";
import { ControleExterno } from "./pages/ControleExterno";
import { Repasses } from "./pages/Repasses";
import { TerceiroSetor } from "./pages/TerceiroSetor";
import { Relatorios } from "./pages/Relatorios";
import { DocumentosFaltantes } from "./pages/DocumentosFaltantes";
import { Denuncia } from "./pages/Denuncia";
import { AssistenteJuridico } from "./pages/AssistenteJuridico";
import { RelatorioDetalhes } from "./pages/RelatorioDetalhes";
import { NotFound } from "./pages/NotFound";
import { Root } from "./Root";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "diario-oficial", Component: DiarioOficial },
      { path: "camara", Component: CamaraLegislativa },
      { path: "contas-publicas", Component: ContasPublicas },
      { path: "controle-externo", Component: ControleExterno },
      { path: "repasses", Component: Repasses },
      { path: "terceiro-setor", Component: TerceiroSetor },
      { path: "relatorios", Component: Relatorios },
      { path: "relatorios/:id", Component: RelatorioDetalhes },
      { path: "documentos-faltantes", Component: DocumentosFaltantes },
      { path: "denuncia", Component: Denuncia },
      { path: "assistente", Component: AssistenteJuridico },
      { path: "*", Component: NotFound },
    ],
  },
]);
